import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';

const canvas = document.querySelector('#scene');
const loading = document.querySelector('#loading');
const startScreen = document.querySelector('#start-screen');
const startButton = document.querySelector('#start-button');
const toast = document.querySelector('#toast');
const crystalCount = document.querySelector('#crystal-count');
const headingText = document.querySelector('#heading');

const scene = new THREE.Scene();
scene.background = new THREE.Color('#9db8bd');
scene.fog = new THREE.FogExp2('#9db8bd', 0.0095);

const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 500);
camera.position.set(0, 5, 11);

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const hemi = new THREE.HemisphereLight('#d9edf0', '#35483c', 2.0);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffe0b0', 3.0);
sun.position.set(-35, 55, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -55; sun.shadow.camera.right = 55;
sun.shadow.camera.top = 55; sun.shadow.camera.bottom = -55;
sun.shadow.bias = -0.00015;
scene.add(sun);
const fill = new THREE.DirectionalLight('#a6d8e8', 1.0);
fill.position.set(20, 15, -30); scene.add(fill);

// Sky haze and distant mountain silhouettes
const skyDome = new THREE.Mesh(new THREE.SphereGeometry(300, 32, 20), new THREE.MeshBasicMaterial({ color: '#a9c6cb', side: THREE.BackSide }));
scene.add(skyDome);
function makeMountainRing(radius, count, height, color, zOffset=0) {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 1, flatShading: true });
  for (let i=0;i<count;i++) {
    const angle = i/count*Math.PI*2;
    const h = height*(0.55+Math.random()*0.8);
    const r = radius + (Math.random()-.5)*12;
    const geo = new THREE.ConeGeometry(5+Math.random()*8, h, 5+Math.floor(Math.random()*3));
    const m = new THREE.Mesh(geo, mat);
    m.position.set(Math.cos(angle)*r, h*.18-5, Math.sin(angle)*r+zOffset);
    m.rotation.y = Math.random()*Math.PI; m.receiveShadow=true; group.add(m);
  }
  scene.add(group); return group;
}
makeMountainRing(75, 34, 20, '#7e9fa4');
makeMountainRing(100, 38, 28, '#a1b9bb', -6);

// Main island: layered rocky underside and rolling terrain
const island = new THREE.Group(); scene.add(island);
const rockMat = new THREE.MeshStandardMaterial({ color: '#4c5b4e', roughness: 1, flatShading: true });
const rockTopMat = new THREE.MeshStandardMaterial({ color: '#63715a', roughness: 1, flatShading: true });
const underside = new THREE.Mesh(new THREE.ConeGeometry(25, 20, 11, 4), rockMat);
underside.position.y = -8; underside.rotation.y = .2; underside.castShadow=true; underside.receiveShadow=true; island.add(underside);
const shelf = new THREE.Mesh(new THREE.CylinderGeometry(24, 25, 3.2, 12, 1), rockTopMat);
shelf.position.y = 0; shelf.castShadow=true; shelf.receiveShadow=true; island.add(shelf);
const terrainGeo = new THREE.PlaneGeometry(48, 48, 48, 48);
terrainGeo.rotateX(-Math.PI/2);
const pos = terrainGeo.attributes.position;
for(let i=0;i<pos.count;i++){
  const x=pos.getX(i), z=pos.getZ(i);
  const edge=Math.max(Math.abs(x),Math.abs(z))/24;
  const y=Math.sin(x*.22)*.55+Math.cos(z*.25)*.5+Math.sin((x+z)*.18)*.3 + (Math.random()-.5)*.18;
  pos.setY(i,y - Math.max(0,edge-.55)*3.2);
}
terrainGeo.computeVertexNormals();
const groundMat = new THREE.MeshStandardMaterial({ color:'#66815c', roughness:1, metalness:0, flatShading:true });
const terrain = new THREE.Mesh(terrainGeo,groundMat); terrain.position.y=1.55; terrain.receiveShadow=true; terrain.castShadow=true; island.add(terrain);

// Curving pale stone trail
const trailMat = new THREE.MeshStandardMaterial({ color:'#b8b39a', roughness:1, flatShading:true });
const trailPoints=[];
for(let i=0;i<16;i++){const t=i/15;trailPoints.push(new THREE.Vector3(-8+16*t,1.78+Math.sin(t*8)*.12,10-20*t));}
const trailCurve=new THREE.CatmullRomCurve3(trailPoints);
const trailGeo=new THREE.TubeGeometry(trailCurve,90,.72,5,false);
const trail=new THREE.Mesh(trailGeo,trailMat);trail.receiveShadow=true;island.add(trail);

// Waterfall ribbons flowing from the floating island
const waterfallMat = new THREE.MeshStandardMaterial({ color:'#b4e1e5', transparent:true, opacity:.72, roughness:.2, metalness:.05, emissive:'#376b75', emissiveIntensity:.25, side:THREE.DoubleSide });
const waterfalls=[];
for(const [x,z,scale] of [[-12,-4,1],[13,1,.8],[3,-15,.65]]){
 const geo=new THREE.PlaneGeometry(3.2*scale,23*scale,4,24);
 const mesh=new THREE.Mesh(geo,waterfallMat);mesh.position.set(x,-11,z);mesh.rotation.y=(x>0?-.25:.2);scene.add(mesh);waterfalls.push(mesh);
}

// Grass tufts, stones, trees and shrubs
const trunkMat=new THREE.MeshStandardMaterial({color:'#514638',roughness:1});
const leafMats=['#354f3c','#496747','#58744d','#6a8051'].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1,flatShading:true}));
const stoneMats=['#7b8373','#858878','#596b61'].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1,flatShading:true}));
const treeGroup=new THREE.Group();island.add(treeGroup);
function makeTree(x,z,s=1){
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18*s,.28*s,2.1*s,6),trunkMat);trunk.position.set(x,2.5*s,z);trunk.castShadow=true;treeGroup.add(trunk);
 for(let j=0;j<3;j++){
   const crown=new THREE.Mesh(new THREE.IcosahedronGeometry((1.1-j*.16)*s,1),leafMats[Math.floor(Math.random()*leafMats.length)]);
   crown.position.set(x+(Math.random()-.5)*.35*s,(3.15+j*.65)*s,z+(Math.random()-.5)*.3*s);crown.scale.y=1.1;crown.castShadow=true;crown.receiveShadow=true;treeGroup.add(crown);
 }
}
for(let i=0;i<65;i++){
 const x=(Math.random()-.5)*42,z=(Math.random()-.5)*42;
 if(Math.abs(x)<5 && z<8 && z>-10)continue;
 if(x*x+z*z>440)continue;
 if(Math.abs(x)<2.5 && z<8 && z>-10)continue;
 if(Math.random()<.72)makeTree(x,z,.65+Math.random()*.75);
 else {const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(.35+Math.random()*.65,0),stoneMats[Math.floor(Math.random()*stoneMats.length)]);rock.position.set(x,1.9,z);rock.scale.y=.6;rock.rotation.set(Math.random(),Math.random(),Math.random());rock.castShadow=true;treeGroup.add(rock);}
}
// Small grass blades in clusters
const grassMat=new THREE.MeshStandardMaterial({color:'#8ca16a',roughness:1,side:THREE.DoubleSide});
const grassGeo=new THREE.ConeGeometry(.09,.6,3);
const grass=new THREE.InstancedMesh(grassGeo,grassMat,460);const dummy=new THREE.Object3D();
for(let i=0;i<460;i++){
 let x=(Math.random()-.5)*43,z=(Math.random()-.5)*43;
 if(x*x+z*z>430){x*=.7;z*=.7;}
 dummy.position.set(x,1.85+Math.random()*.12,z);dummy.rotation.set((Math.random()-.5)*.2,Math.random()*Math.PI*2,(Math.random()-.5)*.2);dummy.scale.setScalar(.5+Math.random()*1.1);dummy.updateMatrix();grass.setMatrixAt(i,dummy.matrix);
}
grass.instanceMatrix.needsUpdate=true;island.add(grass);

// Crystal collectibles
const crystals=[];const crystalMat=new THREE.MeshStandardMaterial({color:'#8de9e1',emissive:'#2dafa7',emissiveIntensity:1.1,roughness:.2,metalness:.15});
const crystalGlow=new THREE.PointLight('#67e9d9',1.7,7);
const crystalSpots=[[-8,1.9,-5],[9,1.9,-7],[12,1.9,8],[-12,1.9,6],[1,1.9,-16]];
for(const [x,y,z] of crystalSpots){
 const g=new THREE.Group();g.position.set(x,y,z);
 const c=new THREE.Mesh(new THREE.OctahedronGeometry(.72,0),crystalMat);c.scale.set(.72,1.55,.72);c.castShadow=true;g.add(c);
 const shard=new THREE.Mesh(new THREE.OctahedronGeometry(.35,0),crystalMat);shard.position.set(.52,.4,.15);shard.rotation.z=.4;g.add(shard);
 const light=new THREE.PointLight('#5ee4d4',1.4,5);light.position.y=.3;g.add(light);scene.add(g);crystals.push({group:g,baseY:y,found:false,phase:Math.random()*6});
}

// Player character, assembled from simple meshes so the project works without model downloads
const player=new THREE.Group();scene.add(player);player.position.set(0,2,9);
const bodyMat=new THREE.MeshStandardMaterial({color:'#344f55',roughness:.82});
const clothMat=new THREE.MeshStandardMaterial({color:'#c28a54',roughness:.9});
const skinMat=new THREE.MeshStandardMaterial({color:'#d7aa83',roughness:.85});
const darkMat=new THREE.MeshStandardMaterial({color:'#252c2c',roughness:.9});
const bootMat=new THREE.MeshStandardMaterial({color:'#342d27',roughness:1});
const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.36,.72,4,8),bodyMat);torso.position.y=1.45;torso.castShadow=true;player.add(torso);
const jacket=new THREE.Mesh(new THREE.BoxGeometry(.56,.72,.25),clothMat);jacket.position.set(0,1.5,.05);jacket.castShadow=true;player.add(jacket);
const head=new THREE.Mesh(new THREE.SphereGeometry(.27,12,10),skinMat);head.position.y=2.18;head.castShadow=true;player.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.28,10,8,0,Math.PI*2,0,Math.PI*.58),darkMat);hair.position.y=2.27;hair.castShadow=true;player.add(hair);
const backpack=new THREE.Mesh(new THREE.BoxGeometry(.4,.53,.2),darkMat);backpack.position.set(0,1.55,-.24);backpack.castShadow=true;player.add(backpack);
const arms=[],legs=[];
for(const side of [-1,1]){
 const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.5,3,6),bodyMat);arm.position.set(side*.43,1.48,.02);arm.rotation.z=side*-.12;arm.castShadow=true;player.add(arm);arms.push(arm);
 const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.52,3,6),darkMat);leg.position.set(side*.18,.65,0);leg.castShadow=true;player.add(leg);legs.push(leg);
 const boot=new THREE.Mesh(new THREE.BoxGeometry(.25,.15,.38),bootMat);boot.position.set(side*.18,.22,.07);boot.castShadow=true;player.add(boot);
}
const shadowDisc=new THREE.Mesh(new THREE.CircleGeometry(.65,20),new THREE.MeshBasicMaterial({color:'#1c2b24',transparent:true,opacity:.25,depthWrite:false}));shadowDisc.rotation.x=-Math.PI/2;shadowDisc.position.y=.05;player.add(shadowDisc);

// Floating rock fragments around the island
for(let i=0;i<36;i++){
 const angle=Math.random()*Math.PI*2,r=27+Math.random()*15,y=-6-Math.random()*17;
 const mesh=new THREE.Mesh(new THREE.DodecahedronGeometry(.5+Math.random()*2.1,0),i%3===0?rockTopMat:rockMat);
 mesh.position.set(Math.cos(angle)*r,y,Math.sin(angle)*r);mesh.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);mesh.castShadow=true;scene.add(mesh);
}

const keys={};let active=false, pointerLocked=false, yaw=0, pitch=.22, verticalVelocity=0, grounded=true, walkTime=0, foundCount=0;
const cameraTarget=new THREE.Vector3();const desiredCamera=new THREE.Vector3();const direction=new THREE.Vector3();const forward=new THREE.Vector3();const right=new THREE.Vector3();
const clock=new THREE.Clock();
function notify(message){toast.textContent=message;toast.classList.add('show');clearTimeout(notify.timer);notify.timer=setTimeout(()=>toast.classList.remove('show'),2300);}
function beginGame(){active=true;startScreen.classList.add('hidden');canvas.requestPointerLock?.();notify('Petualangan dimulai — temukan kristal yang bercahaya.');}
startButton.addEventListener('click',beginGame);
document.addEventListener('pointerlockchange',()=>{pointerLocked=document.pointerLockElement===canvas;});
document.addEventListener('mousemove',(e)=>{if(!active)return;if(pointerLocked){yaw-=e.movementX*.0022;pitch-=e.movementY*.0018;pitch=THREE.MathUtils.clamp(pitch,-.15,.78);}else if(e.buttons===2){yaw-=e.movementX*.004;pitch=THREE.MathUtils.clamp(pitch-e.movementY*.003,-.15,.78);}});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Space'&&active&&grounded){verticalVelocity=7.2;grounded=false;}});
document.addEventListener('keyup',e=>keys[e.code]=false);
window.addEventListener('blur',()=>{for(const k in keys)keys[k]=false;});

function updatePlayer(dt){
 if(!active)return;
 const inputX=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);
 const inputZ=(keys.KeyS||keys.ArrowDown?1:0)-(keys.KeyW||keys.ArrowUp?1:0);
 const moving=inputX!==0||inputZ!==0;
 forward.set(-Math.sin(yaw),0,-Math.cos(yaw));right.set(Math.cos(yaw),0,-Math.sin(yaw));
 direction.set(0,0,0);direction.addScaledVector(right,inputX);direction.addScaledVector(forward,-inputZ);
 if(direction.lengthSq()>0)direction.normalize();
 const speed=(keys.ShiftLeft||keys.ShiftRight)?9.3:5.3;
 player.position.addScaledVector(direction,speed*dt);
 // Keep the player on the main island's walkable area
 const radius=Math.hypot(player.position.x,player.position.z);
 if(radius>20.8){player.position.x*=20.8/radius;player.position.z*=20.8/radius;}
 if(moving){const targetRot=Math.atan2(direction.x,direction.z);let diff=THREE.MathUtils.euclideanModulo(targetRot-player.rotation.y+Math.PI,Math.PI*2)-Math.PI;player.rotation.y+=diff*Math.min(1,dt*12);walkTime+=dt*speed;}
 const swing=moving?Math.sin(walkTime*1.6)*.55:0;
 legs[0].rotation.x=swing;legs[1].rotation.x=-swing;arms[0].rotation.x=-swing*.7;arms[1].rotation.x=swing*.7;
 verticalVelocity-=18*dt;player.position.y+=verticalVelocity*dt;
 if(player.position.y<2){player.position.y=2;verticalVelocity=0;grounded=true;}
 // Find crystals by proximity
 for(const crystal of crystals){if(!crystal.found&&player.position.distanceTo(crystal.group.position)<2.15){crystal.found=true;crystal.group.visible=false;foundCount++;crystalCount.textContent=`${foundCount} / ${crystals.length} ditemukan`;notify(foundCount===crystals.length?'Semua kristal ditemukan! Hebat, penjelajah.':'Kristal kuno ditemukan!');}}
}
function updateCamera(dt){
 cameraTarget.set(player.position.x,player.position.y+1.45,player.position.z);
 const distance=7.5;
 desiredCamera.set(cameraTarget.x+Math.sin(yaw)*Math.cos(pitch)*distance,cameraTarget.y+2.3+Math.sin(pitch)*distance,cameraTarget.z+Math.cos(yaw)*Math.cos(pitch)*distance);
 camera.position.lerp(desiredCamera,1-Math.pow(.001,dt));camera.lookAt(cameraTarget);
 const deg=(THREE.MathUtils.radToDeg(yaw)+360)%360;headingText.textContent=String(Math.round(deg)).padStart(3,'0')+'°';
}
function animateWorld(t,dt){
 crystals.forEach(c=>{if(!c.found){c.group.position.y=c.baseY+Math.sin(t*1.7+c.phase)*.18;c.group.rotation.y=t*.55+c.phase;}});
 waterfalls.forEach((w,i)=>{w.position.x += Math.sin(t*1.4+i)*.002;w.material.opacity=.58+Math.sin(t*2+i)*.08;});
 grass.rotation.y=Math.sin(t*.12)*.005;
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.035);const t=clock.elapsedTime;updatePlayer(dt);updateCamera(dt);animateWorld(t,dt);renderer.render(scene,camera);}

window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));});
loading.classList.add('hidden');
// Initial cinematic framing of the island
camera.position.set(0,9,29);camera.lookAt(0,2,0);
setTimeout(()=>loading.style.display='none',450);
animate();
