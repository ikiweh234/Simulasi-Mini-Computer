# Skybound — 3D Exploration Website

Website game eksplorasi 3D berbasis HTML, CSS, JavaScript, dan Three.js. Dunia dibuat secara prosedural dari geometri Three.js sehingga tidak membutuhkan file model 3D eksternal.

## Fitur
- Dunia pulau terapung dengan medan, pepohonan, batu, kabut, pencahayaan, bayangan, dan air terjun bergaya sinematik.
- Karakter orang ketiga sederhana yang bisa berjalan, berlari, dan melompat.
- Kamera mengikuti karakter dan dapat diputar dengan mouse.
- Lima kristal bercahaya yang bisa ditemukan.
- UI game responsif.

## Menjalankan di Windows
Three.js diimpor sebagai JavaScript module dari CDN, jadi jalankan lewat server lokal (jangan membuka `index.html` dengan double-click/file://).

### Cara A — Python
1. Ekstrak ZIP ini ke sebuah folder.
2. Pastikan Python sudah terpasang. Buka folder `dunia3d-game` di File Explorer.
3. Klik address bar folder, ketik `cmd`, lalu tekan Enter.
4. Jalankan:
   ```bash
   python -m http.server 8000
   ```
5. Buka browser dan kunjungi `http://localhost:8000`.

Jika perintah `python` tidak dikenali, coba `py -m http.server 8000`.

### Cara B — Visual Studio Code
1. Buka folder proyek di VS Code.
2. Pasang ekstensi **Live Server** jika belum ada.
3. Klik kanan `index.html` → **Open with Live Server**.

## Kontrol
- **W / A / S / D** atau tombol panah: bergerak.
- **Mouse**: putar kamera setelah menekan tombol Mulai Menjelajah (pointer lock).
- **Klik kanan + gerakkan mouse**: alternatif memutar kamera tanpa pointer lock.
- **Shift**: berlari.
- **Space**: melompat.
- Dekati kristal bercahaya untuk mengumpulkannya.
- Tekan `Esc` untuk melepas pointer lock. Klik area game lalu mulai lagi jika ingin mengunci pointer.

## Catatan
- Koneksi internet diperlukan untuk memuat Three.js dari jsDelivr dan font dari Google Fonts.
- Performa bergantung pada GPU dan browser. Jika terasa berat, ubah `renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8))` menjadi `1.2` atau kurangi jumlah pohon/rumput di `main.js`.
- Ini adalah prototipe eksplorasi; medan belum memiliki collision presisi dan model karakter dibuat dari bentuk geometris sederhana.
